/**
 * 
 */
package application;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * @author Josh
 *
 */
public class Main extends Application {
  // store any command-line arguments that were entered.
  // NOTE: this.getParameters().getRaw() will get these also

  private List<String> args;

  private static final int WINDOW_WIDTH = 300;
  private static final int WINDOW_HEIGHT = 200;
  private static final String APP_TITLE = "Hello World!";

  @Override
  public void start(Stage primaryStage) throws Exception {
    // save args example
    args = this.getParameters().getRaw();

    // Create a vertical box with Hello labels for each args
    VBox vbox = new VBox();

    // Creates a canvas that can draw shapes and text
    Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
    GraphicsContext gc = canvas.getGraphicsContext2D();
    // Write some text
    // Text is filled with the fill color
    gc.setFill(Color.GREEN);
    gc.setFont(new Font(20));
    gc.fillText("CS400 MyFirstJavaFX", 60, 30);
    
    // create borders
    BorderPane borders = new BorderPane();
    
    // set top
    Text title = new Text("CS400 MyFirstJavaFX");
    borders.setTop(title);
    BorderPane.setAlignment(title, Pos.TOP_CENTER);
    
    // create drop box with three options
    // options
    String optionList[] = {"option 1", "option 2", "option 3"};

    // Create a combo box
    ComboBox combo_box = new ComboBox(FXCollections.observableArrayList(optionList));
    borders.setLeft(combo_box);
    BorderPane.setAlignment(combo_box, Pos.CENTER_LEFT);

    
    // add image
    InputStream inputstream = new FileInputStream("C:\\Users\\Josh\\eclipse-workspace\\HelloFX\\application\\me_picture.jpg");
    Image picture = new Image(inputstream, 120, 130, true, true);
    ImageView iv = new ImageView();
    iv.setImage(picture);

    borders.setCenter(iv);
    BorderPane.setAlignment(iv, Pos.CENTER);
    
    // set bottom
    Button button = new Button("done");
    borders.setBottom(button);
    BorderPane.setAlignment(button, Pos.BOTTOM_CENTER);
   
    // set right
    TextField text = new TextField();
    borders.setRight(text);
    BorderPane.setAlignment(text, Pos.CENTER_RIGHT);
    
    
    /*
    // Draw a line
    // Lines use the stroke color
    gc.setStroke(Color.BLUE);
    gc.setLineWidth(2);
    gc.strokeLine(40, 100, 250, 50);
    // Draw a few circles
    gc.setFill(Color.BLACK);
    // The circles draw from the top left, so to center them, subtract the radius from each
    // coordinate
    gc.fillOval(40 - 15, 100 - 15, 30, 30);
    gc.setFill(Color.RED);
    gc.fillOval(250 - 15, 50 - 15, 30, 30);
    */

    vbox.getChildren().add(canvas);

    // Main layout is Border Pane example (top,left,center,right,bottom)
    BorderPane root = new BorderPane();

    // Add the vertical box to the center of the root pane
    root.setCenter(vbox);
    Scene mainScene = new Scene(borders, WINDOW_WIDTH, WINDOW_HEIGHT);

    // Add the stuff and set the primary stage
    primaryStage.setTitle(APP_TITLE);
    primaryStage.setScene(mainScene);
    primaryStage.show();
  }



  /**
   * @param args
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub

    launch(args);

  }

}
