/**
 * sites used: https://docs.oracle.com/javase/8/javafx/api/javafx/scene/image/ImageView.html
 * https://docs.oracle.com/javase/8/javafx/api/javafx/scene/layout/BorderPane.html
 * https://examples.javacodegeeks.com/desktop-java/javafx/javafx-borderpane-example/#create
 * https://docs.oracle.com/en/java/javase/11/docs/api/java.desktop/java/awt/Button.html
 * https://docs.oracle.com/javafx/2/ui_controls/text-field.htm
 */
package application;

import java.io.FileInputStream;
import java.io.InputStream;
import java.util.List;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

/**
 * @author Josh
 *
 */
public class Main extends Application {
  // store any command-line arguments that were entered.
  // NOTE: this.getParameters().getRaw() will get these also

  private List<String> args;

  private static final int WINDOW_WIDTH = 600;
  private static final int WINDOW_HEIGHT = 400;
  private static final String APP_TITLE = "Hello World!";

  @Override
  public void start(Stage primaryStage) throws Exception {
    // save args example
    args = this.getParameters().getRaw();

    // Create a vertical box with Hello labels for each args
    VBox vbox = new VBox();
    Canvas canvas = new Canvas(WINDOW_WIDTH, WINDOW_HEIGHT);
    
    /*
    // Creates a canvas that can draw shapes and text
    
    GraphicsContext gc = canvas.getGraphicsContext2D();
    // Write some text
    // Text is filled with the fill color
    gc.setFill(Color.GREEN);
    gc.setFont(new Font(20));
    gc.fillText("CS400 MyFirstJavaFX", 60, 30);
    */
    
    // create borders
    BorderPane borders = new BorderPane();
    
    /*
    BackgroundSize bSize = new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false);
    InputStream inputstream = new FileInputStream("C:\\Users\\Josh\\eclipse-workspace\\HelloFX\\backg.jpg");
    Image background = new Image(inputstream, 200, 300, true, true);
    borders.setBackground(new Background(new BackgroundImage(background, BackgroundRepeat.NO_REPEAT,
        BackgroundRepeat.NO_REPEAT,
        BackgroundPosition.CENTER,
        bSize)));
    */
    
    // set top
    VBox topBox = new VBox();
    Font titleText = new Font(30);
    Font userText = new Font(15);
    Text title = new Text("Social Network");
    String currUser = "Debb";
    Text user = new Text("Current User: " + currUser);
    title.setFont(titleText);
    user.setFont(userText);
    topBox.getChildren().add(title);
    topBox.getChildren().add(user);
    borders.setTop(topBox);
    BorderPane.setAlignment(title, Pos.TOP_LEFT);
    
    
    
    
    // create drop box with three options
    // options
    String optionList[] = {"Add User", "Remove User", "Add Friendship", "Remove Friendship", "Clear All"};

    // set left
    VBox leftBox = new VBox();
    ComboBox combo_box = new ComboBox(FXCollections.observableArrayList(optionList));
    //borders.setLeft(combo_box);
    
    
    TextField text1 = new TextField();
    //borders.setLeft(text1);
    //BorderPane.setAlignment(text1, Pos.BOTTOM_CENTER);
    
    TextField text2 = new TextField();
    //borders.setLeft(text2);
    //BorderPane.setAlignment(text2, Pos.BOTTOM_RIGHT);
    
    Button confirmButton = new Button("Confirm");    
    
    leftBox.getChildren().add(text1);
    leftBox.getChildren().add(text2);
    leftBox.getChildren().add(combo_box);
    leftBox.getChildren().add(confirmButton);
    borders.setLeft(leftBox);
    BorderPane.setAlignment(leftBox, Pos.BOTTOM_LEFT);
    
    
    // creating pop up
    

    /*
    // add image
    InputStream inputstream = new FileInputStream("C:\\Users\\Josh\\eclipse-workspace\\HelloFX\\application\\me_picture.jpg");
    Image picture = new Image(inputstream, 120, 130, true, true);
    ImageView iv = new ImageView();
    iv.setImage(picture);

    //borders.setCenter(iv);
    //BorderPane.setAlignment(iv, Pos.CENTER);
    */
    Button b= new Button("Confirm");
    ObservableList<String> List = FXCollections.<String>observableArrayList("Will","David","John","Josh");
    ListView<String> friends = new ListView<>(List);
    friends.setOrientation(Orientation.VERTICAL);
    VBox selection = new VBox();
    selection.setSpacing(10);
    selection.getChildren().addAll(friends,b);
    //Set Center
    GridPane centerPane = new GridPane();
    centerPane.setMaxSize(200, 200);
    centerPane.setVgap(5);
    centerPane.setHgap(5);
    centerPane.setAlignment(Pos.CENTER);
    centerPane.addColumn(0,selection);  
    
    //Adding test elements to the grid pane
//    centerPane.add(text1, 0, 0);
    
    //add to the borderpane
    borders.setCenter(centerPane);
    
    
 
    
    // set bottom
    VBox botBox = new VBox();
    Button button = new Button("Exit");
    borders.setBottom(button);
    BorderPane.setAlignment(button, Pos.BOTTOM_RIGHT);
    
    
    // set right
    VBox rightBox = new VBox();
    Button load = new Button("Load");
    Button write = new Button("Write");
    rightBox.getChildren().addAll(load,write);
    borders.setRight(rightBox);
//    TextField text = new TextField();
//    borders.setRight(text);
//    BorderPane.setAlignment(text, Pos.CENTER_RIGHT);
    
    
    
    vbox.getChildren().add(canvas);

    // Main layout is Border Pane example (top,left,center,right,bottom)
    BorderPane root = new BorderPane();

    // Add the vertical box to the center of the root pane
    root.setCenter(vbox);
    Scene mainScene = new Scene(borders, WINDOW_WIDTH, WINDOW_HEIGHT);

    // Add the stuff and set the primary stage
    primaryStage.setTitle(APP_TITLE);
    primaryStage.setScene(mainScene);
    primaryStage.show();
    
    
    BorderPane pop = new BorderPane();
    VBox popUpBox= new VBox();
    TextField fileInput = new TextField("File Name");
    Button save = new Button("Save and exit");
    Button exit = new Button("Don't save and exit");
    popUpBox.getChildren().addAll(fileInput, save,exit);
    pop.setCenter(popUpBox);
    Scene popup = new Scene(pop);
    button.setOnAction(e->primaryStage.setScene(popup));
  }



  /**
   * @param args
   */
  public static void main(String[] args) {
    // TODO Auto-generated method stub

    launch(args);

  }

}
