package application;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * Filename: Graph.java Project: p4 Authors:
 * 
 * Directed and unweighted graph implementation
 */

public class Graph implements GraphADT {
  
  

  /*
   * Default no-argument constructor
   */
  public Graph() {

  }

  private ArrayList<ArrayList<String>> graph = new ArrayList<ArrayList<String>>();


  /**
   * Add new vertex to the graph.
   *
   * If vertex is null or already exists, method ends without adding a vertex or throwing an
   * exception.
   * 
   * Valid argument conditions: 1. vertex is non-null 2. vertex is not already in the graph
   */
  public void addVertex(String vertex) {

    // catch null vertex
    if (vertex == null || vertex == "") {
      System.out.println("Null vertex: addVertex()");
      return;
    }

    // catch existing vertex
    Set<String> vertSet = getAllVertices();
    if (vertSet.contains(vertex)) {
      System.out.println("vertex already exists: addVertex()");
      return;
    }

    // add valid vertex
    ArrayList<String> newVertex = new ArrayList<String>();
    newVertex.add(vertex);
    graph.add(newVertex);

    return;
  }

  /**
   * Remove a vertex and all associated edges from the graph.
   * 
   * If vertex is null or does not exist, method ends without removing a vertex, edges, or throwing
   * an exception.
   * 
   * Valid argument conditions: 1. vertex is non-null 2. vertex is not already in the graph
   */
  public void removeVertex(String vertex) {

    // catch null vertex
    if (vertex == null || vertex == "") {
      System.out.println("Null vertex: removeVertex()");
      return;
    }

    // catch non-existing vertex
    Set<String> vertSet = getAllVertices();
    if (!vertSet.contains(vertex)) {
      System.out.println("vertex not found in graph: removeVertex()");
      return;
    }

    // remove valid vertex and edges
    for (int i = 0; i < graph.size(); i += 1) {
      if (graph.get(i).get(0).equals(vertex)) {
        graph.remove(i);
      }
    }
    return;
  }

  /**
   * Add the edge from vertex1 to vertex2 to this graph. (edge is directed and unweighted) If either
   * vertex does not exist, add vertex, and add edge, no exception is thrown. If the edge exists in
   * the graph, no edge is added and no exception is thrown.
   * 
   * Valid argument conditions: 1. neither vertex is null 2. both vertices are in the graph 3. the
   * edge is not in the graph
   */
  public void addEdge(String vertex1, String vertex2) {

    // catches null vertices
    if (vertex1 == null || vertex2 == null) {
      System.out.println("Null vertex: addEdge()");
      return;
    }

    // create vertices if either one doesn't exist
    Set<String> vertSet = getAllVertices();
    if (!vertSet.contains(vertex1)) {
      addVertex(vertex1);
    }
    if (!vertSet.contains(vertex2)) {
      addVertex(vertex2);
    }

    // check if edge exists
    for (int i = 0; i < graph.size(); i += 1) {
      if (graph.get(i).get(0).equals(vertex1)) {
        ArrayList<String> v1 = graph.get(i);
        for (int j = 1; j < v1.size(); j += 1) {
          if (v1.get(j).equals(vertex2)) {
            System.out.println("Edge already exists: addEdge()");
            return;
          }
        }
      }
    }

    // adds edge from vertex1 to vertex2
    for (int i = 0; i < graph.size(); i += 1) {
      if (graph.get(i).get(0).equals(vertex1)) {
        graph.get(i).add(vertex2);
      }
    }
    return;
  }

  /**
   * Remove the edge from vertex1 to vertex2 from this graph. (edge is directed and unweighted) If
   * either vertex does not exist, or if an edge from vertex1 to vertex2 does not exist, no edge is
   * removed and no exception is thrown.
   * 
   * Valid argument conditions: 1. neither vertex is null 2. both vertices are in the graph 3. the
   * edge from vertex1 to vertex2 is in the graph
   */
  public void removeEdge(String vertex1, String vertex2) {

    // catches null vertices
    if (vertex1 == null || vertex2 == null) {
      System.out.println("Null vertex: removeEdge()");
      return;
    }

    // check if vertices exist
    Set<String> vertSet = getAllVertices();
    if (!vertSet.contains(vertex1)) {
      System.out.println("vertex1 not contained: removeEdge()");
      return;
    }
    if (!vertSet.contains(vertex2)) {
      System.out.println("vertex2 not contained: removeEdge()");
      return;
    }

    // check if edge exists
    boolean contained = false;
    ArrayList<String> v1 = null;
    for (int i = 0; i < graph.size(); i += 1) {
      if (graph.get(i).get(0).equals(vertex1)) {
        v1 = graph.get(i);
        for (int j = 1; j < v1.size(); j += 1) {
          if (v1.get(j).equals(vertex2)) {
            contained = true;
          }
        }
      }
    }
    if(!contained) {
      System.out.println("edge does not exist: removeEdge()");
      return;
    }
    
    // removes existing edge
    for (int j = 1; j < v1.size(); j += 1) {
      if (v1.get(j).equals(vertex2)) {
        v1.remove(j);
      }
    }
    return;
  }

  /**
   * Returns a Set that contains all the vertices
   * 
   */
  public Set<String> getAllVertices() {
        
    Set<String> vertList = new HashSet<String>();
    for(int i = 0; i < graph.size(); i += 1) {
      vertList.add(graph.get(i).get(0));
    }
    return vertList;
  }

  /**
   * Get all the neighbor (adjacent) vertices of a vertex
   *
   */
  public List<String> getAdjacentVerticesOf(String vertex) {
    
    //checks if vertex is null
    if(vertex == null || vertex == "") {
      System.out.println("vertex is null: getAdjacentVerticesOf()");
      return null;
    }
    
    // checks if vertex is contained in graph
    Set<String> vertSet = getAllVertices();
    if (!vertSet.contains(vertex)) {
      System.out.println("vertex not found in graph: getAdjacentVerticesOf()");
      return null;
    }

    // gets list of neighbors
    for(int i = 0; i < graph.size(); i += 1) {
      if(graph.get(i).get(0).equals(vertex)) {
        ArrayList<String> v1 = graph.get(i);
        List<String> neighbors = new ArrayList<String>();
        for(int j = 1; j < v1.size(); j += 1) {
          neighbors.add(v1.get(j));
        }
        return neighbors;
      }
    }
    
    System.out.println("Should not be here?: getAdjacentVerticesOf()");
    return null;
  }

  /**
   * Returns the number of edges in this graph.
   */
  public int size() {
    
    int size = 0; 
    for(int i = 0; i < graph.size(); i += 1) {
      ArrayList<String> currVertex = graph.get(i);
      for(int j = 1; j < currVertex.size(); j += 1) {
        size += 1;
      }
    }
    
    return size;
  }

  /**
   * Returns the number of vertices in this graph.
   */
  public int order() {
    
    int order = 0;
    for(int i = 0; i < graph.size(); i += 1) {
      order += 1;
    }
    
    return order;
  }
  
  
}
